var AWS = require('aws-sdk');

// DynamoDB and IoT Data clients
var dynamodb = new AWS.DynamoDB();
var docClient = new AWS.DynamoDB.DocumentClient();
var iotdata = new AWS.IotData({ endpoint: "a3izg57fzfchlz-ats.iot.us-east-1.amazonaws.com" });

// Table name can be provided via env var TABLE_NAME, default to 'MaxGuardData'
var TABLE_NAME = process.env.TABLE_NAME || 'my_maxguard_db';

// Shared CORS headers for all responses
const CORS_HEADERS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
};

async function ensureTableExists() {
    try {
        const desc = await dynamodb.describeTable({ TableName: TABLE_NAME }).promise();
        const ks = desc.Table.KeySchema || [];
        ensureTableExists.hashKeyName = ks[0] ? ks[0].AttributeName : 'device_id';
        ensureTableExists.rangeKeyName = ks[1] ? ks[1].AttributeName : 'time';
        return;
    } catch (err) {
        if (err.code !== 'ResourceNotFoundException') throw err;
        var params = {
            TableName: TABLE_NAME,
            KeySchema: [
                { AttributeName: 'device_id', KeyType: 'HASH' },
                { AttributeName: 'time', KeyType: 'RANGE' }
            ],
            AttributeDefinitions: [
                { AttributeName: 'device_id', AttributeType: 'N' },
                { AttributeName: 'time', AttributeType: 'S' }
            ],
            ProvisionedThroughput: { ReadCapacityUnits: 5, WriteCapacityUnits: 5 }
        };
        await dynamodb.createTable(params).promise();
        await dynamodb.waitFor('tableExists', { TableName: TABLE_NAME }).promise();
        ensureTableExists.hashKeyName = 'device_id';
        ensureTableExists.rangeKeyName = 'time';
    }
}

exports.handler = async function(event, context) {
    let payload = event;
    if (typeof event === 'string') {
        try { payload = JSON.parse(event); } catch (e) { }
    }
    if (event && event.body) {
        try { payload = JSON.parse(event.body); } catch (e) { }
    }
    if (event && event.payload) {
        try { payload = typeof event.payload === 'string' ? JSON.parse(event.payload) : event.payload; } catch (e) { }
    }

    // --- 1. HANDLE DASHBOARD READ REQUESTS (GET) ---
    if (event && event.httpMethod === 'GET') {
        const q = event.queryStringParameters || {};
        const qDevice = q.device_id || q.deviceId || 1; // Default to device 1 if not provided
        const limit = Number(q.limit) || 20;

        try {
            await ensureTableExists();
            const params = {
                TableName: TABLE_NAME,
                KeyConditionExpression: '#did = :did',
                ExpressionAttributeNames: { '#did': ensureTableExists.hashKeyName },
                ExpressionAttributeValues: { ':did': Number(qDevice) },
                ScanIndexForward: false, // Newest items first
                Limit: limit
            };
            const res = await docClient.query(params).promise();
            
            return { 
                statusCode: 200, 
                headers: CORS_HEADERS, 
                body: JSON.stringify(res.Items) 
            };
        } catch (err) {
            console.error('Read error', err);
            return { 
                statusCode: 500, 
                headers: CORS_HEADERS, 
                body: JSON.stringify({ error: 'Read failed', detail: err.message }) 
            };
        }
    }

    // --- 2. HANDLE SENSOR DATA INGEST (POST/IOT) ---
    const device_id = Number(payload.device_id || payload.deviceId || 1);
    const distance = Number(payload.distance || payload.dist || 0);
    const light_level = Number(payload.light_level || payload.light || 0);
    const motion_detected = payload.motion_detected === true || payload.motion === true || false;
    const time = new Date().toISOString();

    try {
        await ensureTableExists();
        const item = {
            device_id: device_id,
            time: time,
            distance: distance,
            light_level: light_level,
            motion_detected: motion_detected
        };

        await docClient.put({ TableName: TABLE_NAME, Item: item }).promise();
        console.log('Saved to DynamoDB', item);

        // Optional: IoT Publish logic if needed
        if (distance < 30) { // Example: Threshold alert
            const params = { 
                topic: 'intrusion/alerts', 
                payload: JSON.stringify({ alert: "Intrusion Detected!", device: device_id }), 
                qos: 0 
            };
            await iotdata.publish(params).promise();
        }

        return { 
            statusCode: 200, 
            headers: CORS_HEADERS, 
            body: JSON.stringify({ saved: true, item: item }) 
        };
    } catch (err) {
        console.error('Put error', err);
        return { 
            statusCode: 500, 
            headers: CORS_HEADERS, 
            body: JSON.stringify({ error: 'Save failed', detail: err.message }) 
        };
    }
};